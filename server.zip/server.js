const express = require("express");
const cors = require("cors");
const app = express();
const db = require('./backend_config/db'); 

const port = 5000;

// Middleware
app.use(express.json());
app.use(cors());

// Import routes
const unitRoutes = require("./routes/units");
const unitLineRoutes = require("./routes/unit_lines");  // Updated
const equipmentRoutes = require("./routes/equipments");
const partRoutes = require("./routes/parts");
const checklistRoutes = require("./routes/Checklist")
const checklistUpdateRoutes = require("./routes/updateChecklist")
const updateAfterMaintenanceValue = require("./routes/afterMaintenance")

// Use routes
app.use("/api/units", unitRoutes);
app.use("/api/unit_lines", unitLineRoutes);  // Updated
app.use("/api/equipments", equipmentRoutes);
app.use("/api/parts", partRoutes);
app.use("/api/checklist", checklistRoutes);
app.use("/api",checklistUpdateRoutes);
app.use("/api",updateAfterMaintenanceValue);

app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
    }

    db.query("SELECT * FROM users WHERE username = ?", [username], async (err, results) => {
        if (err) {
            console.error("Database error:", err);
            return res.status(500).json({ message: "Internal Server Error" });
        }

        if (results.length === 0) {
            return res.status(401).json({ message: "Invalid username or password" });
        }

        const user = results[0];

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: "Invalid username or password" });
        }

        const token = jwt.sign({ id: user.username }, process.env.JWT_SECRET || "secretkey", { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    });
});

// Start server


app.listen(port, '0.0.0.0', () => {
    console.log(`✅ Server is running on port ${port}`);
});

